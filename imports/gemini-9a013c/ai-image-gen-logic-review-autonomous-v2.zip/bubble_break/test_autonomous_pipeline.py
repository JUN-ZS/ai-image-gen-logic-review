#!/usr/bin/env python3
"""Unit tests for the zero-touch autonomous closed-loop pipeline (`autonomous_pipeline.py`)."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from bubble_break.autonomous_pipeline import (
    AUTONOMOUS_STAGE_SEQUENCE,
    audit_candidate_frame,
    render_synthetic_stage_raster,
    run_autonomous_pipeline,
)
from bubble_break.dense_hammer_bubble_workflow import (
    auto_select_candidate,
    estimate_candidate_roi,
    make_candidates,
)


class AutonomousPipelineTests(unittest.TestCase):
    def test_auto_select_candidate_deterministically_picks_c13(self) -> None:
        candidates = make_candidates()
        winner, ranking = auto_select_candidate(candidates)
        self.assertEqual(winner.candidate_id, "C13")
        self.assertGreater(ranking[0]["total_score"], 0.85)
        roi = estimate_candidate_roi(winner)
        self.assertEqual(len(roi), 4)
        self.assertGreater(roi[2], 100)
        self.assertGreater(roi[3], 100)

    def test_fault_injection_triggers_auto_rejection_and_rollback(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            outdir = Path(td) / "auto_run"
            report = run_autonomous_pipeline(outdir, simulate_fault_injection=True)
            self.assertTrue(report.all_stages_passed)
            self.assertEqual(report.selected_candidate_id, "C13")
            self.assertEqual(report.passed_stages, len(AUTONOMOUS_STAGE_SEQUENCE))
            self.assertEqual(report.auto_rejections_and_rollbacks, 2)
            failed_attempts = [a for a in report.attempt_history if not a["passed"]]
            self.assertEqual(len(failed_attempts), 2)
            self.assertEqual(failed_attempts[0]["stage"], "D2")
            self.assertTrue(any("outer_end_empty" in r for r in failed_attempts[0]["rejection_reasons"]))
            self.assertEqual(failed_attempts[1]["stage"], "E_END")
            self.assertTrue(any("left_handle_direction_lock" in r for r in failed_attempts[1]["rejection_reasons"]))
            self.assertEqual(len(report.video_transition_manifest), 5)
            self.assertTrue((outdir / "AUTONOMOUS_RUN_MANIFEST.json").is_file())
            self.assertTrue((outdir / "AUTONOMOUS_AUDIT_SUMMARY_BOARD.jpg").is_file())

    def test_grid_split_candidate_is_rejected_by_single_frame_gate(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            grid_p = Path(td) / "grid_fault.jpg"
            render_synthetic_stage_raster(grid_p, "B", inject_fault="grid_split")
            passed, score, gates, reasons = audit_candidate_frame("B", grid_p)
            self.assertFalse(passed)
            self.assertTrue(any("single_full_frame_no_grid" in r for r in reasons))


if __name__ == "__main__":
    unittest.main()
