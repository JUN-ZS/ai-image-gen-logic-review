#!/usr/bin/env python3
"""Autonomous Closed-Loop Image Generation, Multi-Camera Zoom, Action Wash & Pre-Contact Windup Anthology Engine.

Upgraded to support:
1. Autonomous Stage-A Candidate Selection (`C13` planted double-ended cylinder with 90° side-middle lateral rod).
2. Post-Selection Camera Switching & Zoom-In / Zoom-Out Matrix (`CAMERA_ZOOM_RIGS`: 85mm/100mm Macro Zoom-In,
   18mm/20mm Ultra-Wide Hero Zoom-Out, 22° Dutch Rooftop Tilt, 24mm Low-Hero Shrine, 28mm Over-Shoulder).
3. Multi-Action Washing (`ACTION_WASH_LIBRARY`) with Protagonist Face Reference Lock (`00082-207.jpg`).
4. Tricky Pre-Contact Windup Air-Gap Gate (`gate_pre_contact_windup_air_gap`):
   - Audits the `H0_PRE_CONTACT_WINDUP` state where the cylinder head is pulled back OFF the bubble surface
     (`Air-Gap > 0`, cylinder has NOT touched the bubble yet!).
   - Automatically REJECTS candidates where the cylinder remains glued/planted to the bubble (`gap_p99 >= 220`)
     or where the cylinder rotates into a sideways mallet (`cap_median_luma >= 75`).
5. Thematic Anthology Album Compilation (`run_thematic_anthology_pipeline`) across multiple themes
   (Emerald Bioluminescent Shrine, Solar Gold Astral Temple, Cyberpunk Neon Rain Rooftop, Studio Master).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import shutil
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Sequence

import numpy as np
from PIL import Image, ImageDraw

from bubble_break.dense_hammer_bubble_workflow import (
    HammerCandidate,
    auto_select_candidate,
    build_packet,
    estimate_candidate_roi,
    make_candidates,
    make_stage_b_prompt,
    make_stage_d_step_prompt,
    make_stage_e_prompt,
)
from bubble_break.stage_d_gates import (
    GateResult,
    _crop,
    _edge_gradient_map,
    _elongation_score,
    _to_gray,
    gate_base_conformal_glow,
    gate_mini_person_scale_1_to_1,
    gate_outer_end_empty,
    gate_side_handle_present,
    gate_single_full_frame_no_grid,
)


AUTONOMOUS_STAGE_SEQUENCE: tuple[str, ...] = (
    "A",
    "B",
    "D0",
    "D1",
    "D2",
    "D3",
    "E_MID",
    "E_END",
)


@dataclass(frozen=True)
class CameraZoomRig:
    rig_id: str
    name_zh: str
    focal_mm: int
    zoom_mode: str  # "ZOOM_IN_MACRO", "ZOOM_OUT_WIDE", "STANDARD_LOCK", "DUTCH_TILT"
    orbit_deg: float
    off_normal_deg: float
    roll_deg: float
    prompt_directive: str


@dataclass(frozen=True)
class ActionWashSpec:
    wash_id: str
    name_zh: str
    theme_id: str
    theme_zh: str
    camera_rig_id: str
    contact_phase: str  # "PLANTED_LOCK", "H0_PRE_CONTACT_AIR_GAP", "H3_IMPACT_SHATTER"
    pose_directive: str
    environment_directive: str


CAMERA_ZOOM_RIGS: dict[str, CameraZoomRig] = {
    "CAM_STANDARD_50MM": CameraZoomRig(
        "CAM_STANDARD_50MM", "標準 50mm 母鏡位", 50, "STANDARD_LOCK", 35.0, 58.0, 0.0,
        "50mm standard cinema lens, three-quarter grazing view keeping radial cylinder, empty outer cap, and upper-left 90° rod legible."
    ),
    "CAM_ZOOM_IN_85MM_SEAM": CameraZoomRig(
        "CAM_ZOOM_IN_85MM_SEAM", "85mm 特寫 ZOOM IN（接縫與外圓面審計）", 85, "ZOOM_IN_MACRO", 28.0, 32.0, 0.0,
        "85mm telephoto macro ZOOM-IN shot (1.8x closer): inspect the bare flat outer circular end cap, the 90° side-middle rod weld, and the glowing circular base contact seam."
    ),
    "CAM_ZOOM_IN_100MM_GRIP": CameraZoomRig(
        "CAM_ZOOM_IN_100MM_GRIP", "100mm 極距 ZOOM IN（主角握側柄特寫）", 100, "ZOOM_IN_MACRO", 35.0, 38.0, 0.0,
        "100mm macro cinema lens ZOOM-IN close-up on the protagonist gripping the 90° side-middle lateral rod while the outer circular end cap in foreground stays 100% bare."
    ),
    "CAM_ZOOM_OUT_18MM_HERO": CameraZoomRig(
        "CAM_ZOOM_OUT_18MM_HERO", "18mm 超廣角低仰 ZOOM OUT（史詩比例）", 18, "ZOOM_OUT_WIDE", 20.0, 62.0, 0.0,
        "18mm ultra-wide low-angle hero ZOOM-OUT revealing the colossal iridescent containment sphere and monumental temple architecture."
    ),
    "CAM_ZOOM_OUT_20MM_CATHEDRAL": CameraZoomRig(
        "CAM_ZOOM_OUT_20MM_CATHEDRAL", "20mm 廣角全景 ZOOM OUT（賽博聖堂全景）", 20, "ZOOM_OUT_WIDE", 40.0, 65.0, 0.0,
        "20mm ultra-wide establishing ZOOM-OUT showing the full giant iridescent sphere, the C13 cylinder + upper-left rod, and grand architectural pillars."
    ),
    "CAM_DUTCH_22DEG_WASH": CameraZoomRig(
        "CAM_DUTCH_22DEG_WASH", "22° 荷蘭斜角動態追焦鏡", 32, "DUTCH_TILT", 70.0, 48.0, 22.0,
        "32mm dynamic 22-degree Dutch roll angle amplifying backward wind-up tension without altering world-space rigid-body cylinder normal."
    ),
    "CAM_LOW_HERO_24MM_GAP": CameraZoomRig(
        "CAM_LOW_HERO_24MM_GAP", "24mm 廣角懸空氣隙審計鏡（蓄力未碰泡）", 24, "STANDARD_LOCK", 15.0, 72.0, -6.0,
        "24mm side-grazing low-hero angle exposing the wide pre-contact air gap between the cylinder's inner circular face and the untouched bubble."
    ),
}


ACTION_WASH_LIBRARY: tuple[ActionWashSpec, ...] = (
    ActionWashSpec(
        "WASH_01_ZOOM_IN_SEAM", "選柱後 ZOOM IN 85mm 接縫微距檢視", "THEME_STUDIO", "暗黑母棚・微距審計",
        "CAM_ZOOM_IN_85MM_SEAM", "PLANTED_LOCK",
        "No person or close-up hand inspection; focus on bare outer circular end cap, 90° side-middle rod weld, and cyan-white base ring.",
        "Dark high-contrast studio void with iridescent soap-film reflections."
    ),
    ActionWashSpec(
        "WASH_02_ZOOM_IN_EMERALD_GRIP", "選柱後 ZOOM IN 100mm 主角握柄特寫", "THEME_EMERALD_SHRINE", "翡翠森靈神殿",
        "CAM_ZOOM_IN_100MM_GRIP", "PLANTED_LOCK",
        "Protagonist (face locked to 00082-207.jpg) grips the 90° side-middle rod with both hands; foreground outer circular cap 100% bare.",
        "Dappled bioluminescent emerald forest shrine with floating spore lights."
    ),
    ActionWashSpec(
        "WASH_03_ZOOM_OUT_ASTRAL_HERO", "換鏡 ZOOM OUT 18mm 低仰角英雄遠景", "THEME_ASTRAL_GOLD", "星塵黃金神殿",
        "CAM_ZOOM_OUT_18MM_HERO", "PLANTED_LOCK",
        "Protagonist (face locked to 00082-207.jpg) in obsidian-gold armor holds the 90° side-middle rod beneath the colossal iridescent bubble.",
        "Grand golden astral desert temple ruins under a starry nebula sky with volumetric god-rays."
    ),
    ActionWashSpec(
        "WASH_04_ZOOM_OUT_CYBER_CATHEDRAL", "換鏡 ZOOM OUT 20mm 賽博暴雨聖堂全景", "THEME_CYBER_RAIN", "霓虹暴雨聖堂",
        "CAM_ZOOM_OUT_20MM_CATHEDRAL", "PLANTED_LOCK",
        "Mini 1:1 warrior braced high on the long upper-left side-middle rod while the giant iridescent bubble floats in the cathedral nave.",
        "Monumental rain-swept cyberpunk neon Gothic cathedral with cyan and magenta wet floor reflections."
    ),
    ActionWashSpec(
        "WASH_05_AIRBORNE_SPIRAL_KICK", "動作多洗：荷蘭斜角騰空旋身飛踢拉弓", "THEME_ASTRAL_GOLD", "星塵黃金神殿",
        "CAM_DUTCH_22DEG_WASH", "PLANTED_LOCK",
        "Mini 1:1 warrior leaps off the cylinder in an airborne spinning high-kick back-arch pose, gripping ONLY the upper-left 90° straight rod.",
        "Golden astral astrolabe temple with swirling golden dust ribbons and dramatic Dutch tilt."
    ),
    ActionWashSpec(
        "WASH_06_H0_STUDIO_AIR_GAP", "Tricky 蓄力（柱未碰泡前）：母棚同軸懸空拉開氣隙", "THEME_STUDIO", "暗黑母棚・懸空蓄力",
        "CAM_LOW_HERO_24MM_GAP", "H0_PRE_CONTACT_AIR_GAP",
        "Entire C13 cylinder + mini 1:1 warrior pulled 150px backward along -n; wide dark empty air gap before intact uncracked bubble.",
        "Dark studio void exposing the clean pre-contact gap between the cylinder's inner circular face and the pristine bubble."
    ),
    ActionWashSpec(
        "WASH_07_H0_NEON_ROOFTOP_AIR_GAP", "Tricky 蓄力（柱未碰泡前）：霓虹雨夜天台荷蘭角拉滿蓄力", "THEME_CYBER_RAIN", "霓虹暴雨天台",
        "CAM_DUTCH_22DEG_WASH", "H0_PRE_CONTACT_AIR_GAP",
        "Warrior braces on wet rooftop pulling the 90° side-middle rod back; heavy cylinder floats in mid-air with a wide air gap before the intact bubble.",
        "Rain-drenched cyberpunk neon magenta-and-cyan rooftop at night with diagonal rain streaks."
    ),
    ActionWashSpec(
        "WASH_08_H0_EMERALD_LEAP_AIR_GAP", "Tricky 蓄力（柱未碰泡前）：翡翠神殿凌空躍起懸空蓄力", "THEME_EMERALD_SHRINE", "翡翠森靈神殿",
        "CAM_LOW_HERO_24MM_GAP", "H0_PRE_CONTACT_AIR_GAP",
        "Warrior leaps into mid-air with streaming dark hair, pulling the 90° side-middle rod back so the cylinder's circular end face hovers across a clear air gap from the intact bubble.",
        "Ancient glowing bioluminescent emerald jungle shrine with vine-wrapped stone arches."
    ),
    ActionWashSpec(
        "WASH_09_H3_EMERALD_IMPACT_SHATTER", "終章正撞破泡（H0 懸空蓄力 ➔ H3 端面正撞爆破）", "THEME_EMERALD_SHRINE", "翡翠森靈神殿",
        "CAM_LOW_HERO_24MM_GAP", "H3_IMPACT_SHATTER",
        "Cylinder advances across the air gap along +n; flat circular end face slams squarely into the bubble, erupting concentric emerald-cyan shockwaves and rainbow crystal shards.",
        "Ancient glowing bioluminescent emerald jungle shrine illuminated by the impact shockwave."
    ),
)


@dataclass
class CandidateAttemptRecord:
    stage: str
    attempt_index: int
    image_path: str
    sha256: str
    parent_sha256: str | None
    elevation_level: str
    passed: bool
    quality_score: float
    gates: list[dict[str, Any]]
    rejection_reasons: list[str] = field(default_factory=list)
    repair_action_taken: str | None = None


@dataclass
class AutonomousPipelineReport:
    workflow: str
    selected_candidate_id: str
    auto_selection_score: float
    total_stages: int
    passed_stages: int
    total_attempts: int
    auto_rejections_and_rollbacks: int
    all_stages_passed: bool
    canonical_sequence: dict[str, dict[str, Any]]
    attempt_history: list[dict[str, Any]]
    video_transition_manifest: list[dict[str, Any]]
    summary_board_path: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_c13_rois() -> dict[str, tuple[float, float, float, float]]:
    """Canonical normalized ROIs for C13 planted double-ended cylinder composition (16:9)."""
    return {
        "outer_cap_roi": (0.24, 0.62, 0.38, 0.84),
        "left_side_handle_roi": (0.14, 0.26, 0.41, 0.56),
        "right_forbidden_handle_roi": (0.52, 0.25, 0.76, 0.55),
        "base_glow_roi": (0.40, 0.46, 0.55, 0.74),
        "air_gap_seam_roi": (0.46, 0.38, 0.62, 0.68),
        "lower_left_drum_roi": (0.08, 0.56, 0.36, 0.88),
        "hammer_roi": (0.15, 0.28, 0.54, 0.78),
        "person_roi": (0.10, 0.16, 0.42, 0.82),
        "bubble_shell_roi": (0.46, 0.14, 0.84, 0.86),
    }


def gate_pre_contact_windup_air_gap(
    image_path: Path,
    air_gap_seam_roi: tuple[float, float, float, float] = (0.46, 0.38, 0.62, 0.68),
    lower_left_drum_roi: tuple[float, float, float, float] = (0.08, 0.56, 0.36, 0.88),
    *,
    max_seam_p99_luma: float = 220.0,
    max_drum_median_luma: float = 75.0,
) -> GateResult:
    """Audit the Tricky Pre-Contact Windup (`H0_PRE_CONTACT_AIR_GAP` — 柱還未碰到泡前!).

    Verifies TWO non-negotiable physical properties of the pre-contact windup state:
    1. `air_gap_separated`: The cylinder head has been pulled back OFF the bubble surface so the
       seam zone between cylinder and bubble does NOT contain a bright planted contact glow ring
       (`seam_p99 < max_seam_p99_luma`). If the cylinder is still stuck/planted on the bubble
       (`seam_p99 >= 220`), this gate FAILS and orders a pullback along `-n`.
    2. `radial_cylinder_orientation`: The heavy dark-steel cylinder drum still occupies the lower-left
       radial axis (`drum_median_luma < max_drum_median_luma`) with its circular end face aimed at the
       bubble, rather than being rotated into a sideways mallet in the upper-middle sky.
    """
    img = Image.open(image_path).convert("RGB")
    gray = _to_gray(np.asarray(img))
    seam_patch = _crop(gray, air_gap_seam_roi)
    drum_patch = _crop(gray, lower_left_drum_roi)

    seam_p99 = float(np.quantile(seam_patch, 0.99))
    seam_mean = float(seam_patch.mean())
    drum_median = float(np.median(drum_patch))

    gap_ok = seam_p99 < max_seam_p99_luma
    drum_ok = drum_median < max_drum_median_luma
    passed = gap_ok and drum_ok

    if passed:
        detail = (
            f"PASS: pre-contact air gap verified (cylinder detached before bubble, "
            f"seam_p99={seam_p99:.1f} < {max_seam_p99_luma:.1f}, drum_median={drum_median:.1f})"
        )
    elif not gap_ok:
        detail = (
            f"FAIL: cylinder head is still touching/planted on bubble during H0 windup "
            f"(seam_p99={seam_p99:.1f} >= {max_seam_p99_luma:.1f}) — REJECT + pull cylinder back along -n"
        )
    else:
        detail = (
            f"FAIL: cylinder rotated into sideways mallet; radial lower-left cylinder drum missing "
            f"(drum_median={drum_median:.1f} >= {max_drum_median_luma:.1f}) — REJECT + restore C13 radial axis"
        )

    return GateResult(
        name="pre_contact_windup_air_gap",
        passed=passed,
        detail=detail,
        metrics={
            "seam_p99_luma": seam_p99,
            "seam_mean_luma": seam_mean,
            "drum_median_luma": drum_median,
        },
    )


def gate_left_handle_not_flipped_to_right(
    image_path: Path,
    left_roi: tuple[float, float, float, float],
    right_roi: tuple[float, float, float, float],
) -> GateResult:
    """Reject frames where the model flips the left-pointing side handle to the right side."""
    img = Image.open(image_path).convert("RGB")
    gray = _to_gray(np.asarray(img))
    edge = _edge_gradient_map(gray)
    left_patch = _crop(gray, left_roi)
    left_edge = _crop(edge, left_roi)
    right_patch = _crop(gray, right_roi)

    m_left = max(
        _elongation_score(left_patch)["elongation"],
        _elongation_score(left_edge, thr_ratio=0.72)["elongation"],
    )
    m_right = _elongation_score(right_patch)["elongation"]
    p = left_patch - left_patch.min()
    span = float(p.max() - p.min()) + 1e-6
    p = p / span
    ys, xs = np.where(p >= max(float(np.quantile(p, 0.70)), 0.22))
    corr = 0.0
    if len(xs) >= 25:
        x_c = xs.astype(np.float64) - xs.mean()
        y_c = ys.astype(np.float64) - ys.mean()
        denom = float(np.sqrt((x_c * x_c).mean() * (y_c * y_c).mean())) + 1e-8
        corr = float((x_c * y_c).mean() / denom)

    passed = m_left >= 1.50 and corr > 0.15
    return GateResult(
        name="left_handle_direction_lock",
        passed=passed,
        detail=(
            f"PASS: left-pointing side handle locked (left_elong={m_left:.2f}, slope_corr={corr:+.2f})"
            if passed
            else f"FAIL: left side handle missing or flipped to right (left_elong={m_left:.2f}, right_elong={m_right:.2f}, slope_corr={corr:+.2f}) — REJECT + rollback"
        ),
        metrics={"left_elongation": m_left, "right_elongation": m_right, "slope_corr": corr},
    )


def gate_stage_e_fracture_progression(
    image_path: Path,
    stage: str,
    bubble_roi: tuple[float, float, float, float],
) -> GateResult:
    """Verify causal fracture energy across B/D1/D2/D3/H0 (intact) vs E_MID (cracks) vs E_END/H3 (shatter)."""
    img = Image.open(image_path).convert("RGB")
    gray = _to_gray(np.asarray(img))
    edge = _edge_gradient_map(gray)
    patch = _crop(edge, bubble_roi)
    high_edge_density = float(np.mean(patch > 18.0))

    if stage in ("B", "D0", "D1", "D2", "D3", "D4", "H0_PRE_CONTACT_AIR_GAP", "PLANTED_LOCK"):
        passed = high_edge_density < 0.28
        detail = (
            f"PASS: bubble shell intact prior to impact (edge_density={high_edge_density:.3f})"
            if passed
            else f"FAIL: premature cracks/debris on bubble in {stage} (edge_density={high_edge_density:.3f})"
        )
    elif stage == "E_MID":
        passed = 0.045 <= high_edge_density <= 0.45
        detail = (
            f"PASS: Stage E_MID radial cracks & shock rings active (edge_density={high_edge_density:.3f})"
            if passed
            else f"FAIL: Stage E_MID fracture density out of range ({high_edge_density:.3f})"
        )
    else:  # E_END or H3_IMPACT_SHATTER
        passed = high_edge_density >= 0.08
        detail = (
            f"PASS: outward bubble shatter spectacle verified (edge_density={high_edge_density:.3f})"
            if passed
            else f"FAIL: insufficient shatter spectacle ({high_edge_density:.3f})"
        )
    return GateResult(
        name="causal_fracture_progression",
        passed=passed,
        detail=detail,
        metrics={"high_edge_density": high_edge_density},
    )


def audit_candidate_frame(
    stage: str,
    image_path: Path,
    prev_sha256: str | None = None,
    rois: dict[str, tuple[float, float, float, float]] | None = None,
) -> tuple[bool, float, list[GateResult], list[str]]:
    """Run all applicable pixel & topological gates for a given stage without human intervention."""
    r = rois or canonical_c13_rois()
    gates: list[GateResult] = []

    gates.append(gate_single_full_frame_no_grid(image_path))
    if stage == "A":
        gates.append(gate_base_conformal_glow(image_path, (0.20, 0.15, 0.80, 0.85), min_peak_luma=140.0))
    elif stage == "H0_PRE_CONTACT_AIR_GAP":
        gates.append(gate_outer_end_empty(image_path, (0.01, 0.68, 0.14, 0.94)))
        gates.append(
            gate_pre_contact_windup_air_gap(
                image_path,
                r["air_gap_seam_roi"],
                r["lower_left_drum_roi"],
            )
        )
        gates.append(gate_stage_e_fracture_progression(image_path, stage, r["bubble_shell_roi"]))
    else:
        if stage in ("D1", "D2", "D3", "D4", "E_MID", "E_END"):
            gates.append(
                GateResult(
                    name="parent_sha_provenance_lock",
                    passed=bool(prev_sha256 and len(prev_sha256) >= 16),
                    detail=(
                        f"PASS: chained from locked parent SHA {prev_sha256[:12]}..."
                        if prev_sha256
                        else "FAIL: missing parent SHA provenance lock"
                    ),
                )
            )
        gates.append(gate_outer_end_empty(image_path, r["outer_cap_roi"]))
        gates.append(gate_side_handle_present(image_path, r["left_side_handle_roi"], min_elongation=1.50))
        gates.append(
            gate_left_handle_not_flipped_to_right(
                image_path,
                r["left_side_handle_roi"],
                r["right_forbidden_handle_roi"],
            )
        )
        gates.append(gate_base_conformal_glow(image_path, r["base_glow_roi"]))
        if stage in ("D1", "D2", "D3", "D4", "E_MID", "E_END"):
            gates.append(gate_mini_person_scale_1_to_1(image_path, r["person_roi"], r["hammer_roi"]))
        gates.append(gate_stage_e_fracture_progression(image_path, stage, r["bubble_shell_roi"]))

    passed = all(g.passed for g in gates)
    reasons = [f"{g.name}: {g.detail}" for g in gates if not g.passed]
    pass_frac = sum(1 for g in gates if g.passed) / max(len(gates), 1)
    bonus = 0.0
    for g in gates:
        if g.name == "left_handle_direction_lock":
            bonus = min(max(g.metrics.get("slope_corr", 0.0), 0.0), 1.0) * 0.15
        elif g.name == "pre_contact_windup_air_gap" and g.passed:
            bonus = 0.12
    score = (0.85 * pass_frac + bonus) if passed else (0.40 * pass_frac)
    return passed, round(min(score, 0.995), 4), gates, reasons


def compile_elevation_prompt_repair(
    candidate: HammerCandidate,
    stage: str,
    prev_sha256: str | None,
    rejection_reasons: Sequence[str],
) -> dict[str, str]:
    """Visual Primitive Compiler auto-repair: collapse k=3 -> k=0 CORE + hard lock injection."""
    reason_blob = " | ".join(rejection_reasons)
    core_k0 = (
        f"AUTO-REPAIR COMPILER PATCH (k=3 -> k=0 CORE LOCK, triggered by: {reason_blob}):\n"
        f"- Source parent SHA-256={prev_sha256 or 'B3_MASTER'} strictly frozen.\n"
        f"- Dark-steel cylinder at lower-left aimed radially at the right-side bubble.\n"
        f"- Outer circular end cap pointing lower-left is 100% EMPTY and BARE.\n"
        f"- Single thin straight metal rod handle attached at 90° to SIDE-MIDDLE pointing upper-left.\n"
        f"- Mini 1:1 East Asian female warrior stays on the UPPER-LEFT gripping ONLY that left rod.\n"
        f"- For H0_PRE_CONTACT_AIR_GAP: pull cylinder back along -n so there is a wide empty air gap BEFORE touching the bubble!\n"
    )
    if stage == "D2":
        base = make_stage_d_step_prompt(candidate, "D2", prev_raster_sha256=prev_sha256, from_step="D1")
    elif stage in ("D3", "H0_PRE_CONTACT_AIR_GAP"):
        base = make_stage_d_step_prompt(candidate, "D3", prev_raster_sha256=prev_sha256, from_step="D2")
    elif stage in ("E_MID", "E_END"):
        base = make_stage_e_prompt(candidate)
    else:
        base = make_stage_b_prompt(candidate, raster_sha256=prev_sha256)
    return {
        "elevation_level": "k=0_CORE_REPAIR_THEN_K3",
        "repaired_prompt": core_k0 + "\n" + base,
    }


def render_synthetic_stage_raster(
    path: Path,
    stage: str,
    *,
    inject_fault: str | None = None,
) -> Path:
    """Deterministic procedural 16:9 raster synthesizer for offline unit/CI verification."""
    w, h = 1280, 720
    img = Image.new("RGB", (w, h), (12, 16, 22))
    draw = ImageDraw.Draw(img)

    if inject_fault == "grid_split":
        for gx in (320, 640, 960):
            draw.line([(gx, 0), (gx, h)], fill=(245, 245, 250), width=6)
        for gy in (180, 360, 540):
            draw.line([(0, gy), (w, gy)], fill=(245, 245, 250), width=6)
        path.parent.mkdir(parents=True, exist_ok=True)
        img.save(path, quality=92)
        return path

    bx, by, br = 780, 360, 250
    if stage == "H0_PRE_CONTACT_AIR_GAP" and inject_fault != "stuck_on_bubble":
        bx = 900  # Bubble on right with wide air gap in (0.46..0.62)
    for r_step in range(br, br - 18, -2):
        c_val = 70 + (br - r_step) * 6
        draw.ellipse([bx - r_step, by - r_step, bx + r_step, by + r_step], outline=(c_val, 180, 210), width=2)

    if stage == "A":
        for idx in range(24):
            ang = idx * (2.0 * math.pi / 24.0)
            cx = int(bx + (br - 10) * math.cos(ang))
            cy = int(by + (br - 10) * math.sin(ang))
            ox = int(bx + (br + 38) * math.cos(ang))
            oy = int(by + (br + 38) * math.sin(ang))
            draw.line([(cx, cy), (ox, oy)], fill=(120, 135, 150), width=20)
            draw.ellipse([cx - 12, cy - 12, cx + 12, cy + 12], outline=(180, 255, 255), width=4)
            tx = int((cx + ox) * 0.5 - 45 * math.sin(ang))
            ty = int((cy + oy) * 0.5 + 45 * math.cos(ang))
            draw.line([((cx + ox) // 2, (cy + oy) // 2), (tx, ty)], fill=(210, 220, 230), width=5)
        path.parent.mkdir(parents=True, exist_ok=True)
        img.save(path, quality=92)
        return path

    if stage == "H0_PRE_CONTACT_AIR_GAP" and inject_fault != "stuck_on_bubble":
        # Detached cylinder shifted lower-left with NO contact glow ring on bubble
        draw.polygon([(435, 435), (495, 525), (345, 615), (285, 525)], fill=(42, 48, 56), outline=(110, 125, 140))
        draw.ellipse([265, 515, 365, 625], fill=(32, 38, 46), outline=(100, 115, 130), width=3)
    else:
        draw.ellipse([545, 385, 645, 505], fill=(160, 250, 255), outline=(255, 255, 255), width=6)
        draw.polygon([(565, 395), (625, 485), (515, 545), (455, 455)], fill=(72, 82, 94), outline=(140, 155, 170))
        draw.ellipse([445, 445, 525, 545], fill=(52, 60, 70), outline=(130, 145, 160), width=3)

    if inject_fault == "outer_end_shaft":
        draw.line([(475, 505), (330, 585)], fill=(235, 240, 245), width=14)

    if inject_fault == "flip_handle_right":
        draw.line([(610, 430), (880, 240)], fill=(225, 235, 245), width=12)
    else:
        draw.line([(535, 445), (235, 225)], fill=(225, 235, 245), width=11)

    if stage in ("D1", "D2", "D3", "D4", "E_MID", "E_END", "H0_PRE_CONTACT_AIR_GAP"):
        px, py = (780, 260) if inject_fault == "flip_handle_right" else ((275, 355) if stage == "D1" else (345, 285))
        draw.ellipse([px - 18, py - 55, px + 18, py - 18], fill=(210, 180, 165), outline=(240, 210, 195), width=2)
        draw.rectangle([px - 22, py - 18, px + 22, py + 55], fill=(35, 40, 48), outline=(150, 160, 175), width=3)
        draw.line([(px - 12, py + 55), (px - 24, py + 125)], fill=(45, 50, 60), width=10)
        draw.line([(px + 12, py + 55), (px + 24, py + 125)], fill=(45, 50, 60), width=10)
        if stage != "D1" and inject_fault != "flip_handle_right":
            draw.line([(px - 18, py), (320, 288)], fill=(160, 170, 185), width=7)
            draw.line([(px + 18, py + 8), (375, 328)], fill=(160, 170, 185), width=7)

    if stage in ("E_MID", "E_END"):
        for r_ring in (75, 115, 160):
            draw.ellipse(
                [595 - r_ring, 445 - r_ring, 595 + r_ring, 445 + r_ring],
                outline=(180, 250, 255),
                width=4,
            )
        for ray_deg in range(-75, 85, 14):
            rad = math.radians(ray_deg)
            r_len = 230 if stage == "E_MID" else 340
            ex = int(595 + r_len * math.cos(rad))
            ey = int(445 + r_len * math.sin(rad))
            draw.line([(595, 445), (ex, ey)], fill=(220, 250, 255), width=3)
        if stage == "E_END":
            for s_idx in range(28):
                ang = math.radians(-80 + s_idx * 6)
                dist = 140 + (s_idx % 5) * 45
                sx = int(595 + dist * math.cos(ang))
                sy = int(445 + dist * math.sin(ang))
                draw.polygon([(sx, sy), (sx + 22, sy - 10), (sx + 10, sy + 18)], fill=(200, 245, 255), outline=(255, 255, 255))

    path.parent.mkdir(parents=True, exist_ok=True)
    img.save(path, quality=92)
    return path


def create_audit_contact_board(
    report: AutonomousPipelineReport,
    out_path: Path,
    title_prefix: str = "AUTONOMOUS SELF-AUDITING PIPELINE",
) -> Path:
    """Render a high-resolution visual audit summary board showing every stage and gate status."""
    stages = list(report.canonical_sequence.keys())
    cols = 4
    rows = math.ceil(len(stages) / cols)
    cell_w, cell_h = 480, 320
    board = Image.new("RGB", (cols * cell_w, rows * cell_h + 70), (14, 18, 24))
    draw = ImageDraw.Draw(board)
    draw.text(
        (24, 20),
        f"{title_prefix} — CANDIDATE {report.selected_candidate_id} "
        f"(PASSED {report.passed_stages}/{report.total_stages} TRACKS | "
        f"AUTO-REJECTS/REPAIRS: {report.auto_rejections_and_rollbacks})",
        fill=(130, 245, 255),
    )

    for idx, st in enumerate(stages):
        info = report.canonical_sequence[st]
        r_idx, c_idx = divmod(idx, cols)
        x0, y0 = c_idx * cell_w, 70 + r_idx * cell_h
        img_p = Path(info["image_path"])
        if img_p.is_file():
            thumb = Image.open(img_p).convert("RGB").resize((cell_w - 16, cell_h - 60))
            board.paste(thumb, (x0 + 8, y0 + 8))
        status_color = (80, 235, 140) if info["passed"] else (255, 95, 95)
        draw.rectangle([x0 + 6, y0 + 6, x0 + cell_w - 6, y0 + cell_h - 6], outline=status_color, width=3)
        label = f"[{st}] {'PASS' if info['passed'] else 'FAIL'} | score={info['quality_score']:.2f} | sha={info['sha256'][:10]}"
        draw.text((x0 + 14, y0 + cell_h - 44), label, fill=status_color)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    board.save(out_path, quality=92)
    return out_path


def build_video_transition_manifest(
    canonical_sequence: dict[str, dict[str, Any]],
    candidate_id: str,
) -> list[dict[str, Any]]:
    """Build the First-to-Last Frame (首尾幀) video transition manifest across the verified sequence."""
    ordered = list(canonical_sequence.keys())
    transitions: list[dict[str, Any]] = []
    for i in range(len(ordered) - 1):
        s_from, s_to = ordered[i], ordered[i + 1]
        transitions.append({
            "segment_id": f"p{i:02d}_{s_from}_to_{s_to}",
            "candidate_id": candidate_id,
            "start_stage": s_from,
            "end_stage": s_to,
            "start_frame": canonical_sequence[s_from]["image_path"],
            "start_sha256": canonical_sequence[s_from]["sha256"],
            "end_frame": canonical_sequence[s_to]["image_path"],
            "end_sha256": canonical_sequence[s_to]["sha256"],
            "fps": 24,
            "duration_sec": 2.5,
            "motion_bucket_id": 127,
            "transition_prompt": (
                f"Smooth rigid-body camera/motion transition from {s_from} to {s_to}; "
                f"preserve radial dark-steel cylinder, 100% bare outer circular cap, and 90° side-middle lateral rod."
            ),
        })
    return transitions


def run_thematic_anthology_pipeline(
    outdir: Path,
    track_candidates_map: dict[str, Sequence[Path]],
    *,
    protagonist_face_ref: Path | None = None,
) -> AutonomousPipelineReport:
    """Execute the Multi-Camera Zoom + Action Wash + Pre-Contact Windup Thematic Anthology Album pipeline."""
    outdir.mkdir(parents=True, exist_ok=True)
    rasters_dir = outdir / "rasters"
    gates_dir = outdir / "gates"
    rasters_dir.mkdir(parents=True, exist_ok=True)
    gates_dir.mkdir(parents=True, exist_ok=True)

    candidates = make_candidates()
    winner, ranking = auto_select_candidate(candidates)

    canonical_sequence: dict[str, dict[str, Any]] = {}
    attempt_history: list[dict[str, Any]] = []
    auto_rejections = 0
    prev_sha: str | None = sha256_file(protagonist_face_ref) if (protagonist_face_ref and protagonist_face_ref.is_file()) else "C13_MASTER_LOCK"

    for wash_spec in ACTION_WASH_LIBRARY:
        track_id = wash_spec.wash_id
        if track_id not in track_candidates_map:
            continue
        stage_files = [Path(p) for p in track_candidates_map[track_id]]
        track_passed = False
        best_attempt: CandidateAttemptRecord | None = None
        elevation = f"k=3_{wash_spec.camera_rig_id}__{wash_spec.theme_id}"

        for idx, cand_path in enumerate(stage_files, start=1):
            sha = sha256_file(cand_path)
            if wash_spec.contact_phase == "H0_PRE_CONTACT_AIR_GAP":
                passed, score, gates, reasons = audit_candidate_frame("H0_PRE_CONTACT_AIR_GAP", cand_path, prev_sha256=prev_sha)
            elif wash_spec.contact_phase == "H3_IMPACT_SHATTER":
                g1 = gate_single_full_frame_no_grid(cand_path)
                g2 = gate_outer_end_empty(cand_path, (0.10, 0.52, 0.36, 0.86))
                g3 = gate_stage_e_fracture_progression(cand_path, "E_END", (0.46, 0.14, 0.88, 0.86))
                gates = [g1, g2, g3]
                passed = all(g.passed for g in gates)
                reasons = [f"{g.name}: {g.detail}" for g in gates if not g.passed]
                score = 0.96 if passed else 0.35
            else:
                # Camera Zoom-In / Zoom-Out / Action Wash inspection
                g1 = gate_single_full_frame_no_grid(cand_path)
                g2 = gate_outer_end_empty(cand_path, (0.08, 0.52, 0.38, 0.86))
                gates = [g1, g2]
                passed = all(g.passed for g in gates)
                reasons = [f"{g.name}: {g.detail}" for g in gates if not g.passed]
                score = 0.94 if passed else 0.35

            repair_note = None
            if not passed:
                auto_rejections += 1
                patch = compile_elevation_prompt_repair(winner, wash_spec.contact_phase, prev_sha, reasons)
                elevation = patch["elevation_level"]
                repair_note = f"AUTO_REJECT_AND_ROLLBACK -> {elevation}"
                (gates_dir / f"REJECTED_{track_id}_attempt{idx:02d}_repair.txt").write_text(
                    patch["repaired_prompt"], encoding="utf-8"
                )

            rec = CandidateAttemptRecord(
                stage=track_id,
                attempt_index=idx,
                image_path=str(cand_path),
                sha256=sha,
                parent_sha256=prev_sha,
                elevation_level=elevation,
                passed=passed,
                quality_score=score,
                gates=[g.to_dict() for g in gates],
                rejection_reasons=reasons,
                repair_action_taken=repair_note,
            )
            attempt_history.append(asdict(rec))
            if passed:
                best_attempt = rec
                track_passed = True
                break
            if best_attempt is None or rec.quality_score > best_attempt.quality_score:
                best_attempt = rec

        assert best_attempt is not None
        locked_dest = rasters_dir / f"LOCKED_{track_id}.jpg"
        if Path(best_attempt.image_path).resolve() != locked_dest.resolve():
            shutil.copy2(best_attempt.image_path, locked_dest)

        canonical_sequence[track_id] = {
            "stage": track_id,
            "name_zh": wash_spec.name_zh,
            "theme_zh": wash_spec.theme_zh,
            "camera_rig": asdict(CAMERA_ZOOM_RIGS[wash_spec.camera_rig_id]),
            "contact_phase": wash_spec.contact_phase,
            "image_path": str(locked_dest),
            "sha256": best_attempt.sha256,
            "parent_sha256": prev_sha,
            "passed": track_passed,
            "quality_score": best_attempt.quality_score,
            "elevation_level": best_attempt.elevation_level,
            "gates": best_attempt.gates,
        }
        if track_passed:
            prev_sha = best_attempt.sha256

    video_manifest = build_video_transition_manifest(canonical_sequence, winner.candidate_id)
    passed_count = sum(1 for item in canonical_sequence.values() if item["passed"])
    report = AutonomousPipelineReport(
        workflow="autonomous-multicamera-zoom-precontact-windup-anthology-album",
        selected_candidate_id=winner.candidate_id,
        auto_selection_score=ranking[0]["total_score"],
        total_stages=len(canonical_sequence),
        passed_stages=passed_count,
        total_attempts=len(attempt_history),
        auto_rejections_and_rollbacks=auto_rejections,
        all_stages_passed=(passed_count == len(canonical_sequence)),
        canonical_sequence=canonical_sequence,
        attempt_history=attempt_history,
        video_transition_manifest=video_manifest,
    )
    board_path = create_audit_contact_board(
        report,
        outdir / "THEMATIC_ANTHOLOGY_ALBUM_BOARD.jpg",
        title_prefix="THEMATIC ANTHOLOGY ALBUM (CAMERA ZOOM + ACTION WASH + H0 PRE-CONTACT AIR-GAP)",
    )
    report.summary_board_path = str(board_path)
    (outdir / "THEMATIC_ANTHOLOGY_MANIFEST.json").write_text(
        json.dumps(report.to_dict(), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return report


def run_autonomous_pipeline(
    outdir: Path,
    *,
    stage_candidates_map: dict[str, Sequence[Path]] | None = None,
    simulate_fault_injection: bool = False,
) -> AutonomousPipelineReport:
    """Execute the complete zero-touch autonomous workflow from Stage A to Stage E + Video Manifest."""
    outdir.mkdir(parents=True, exist_ok=True)
    rasters_dir = outdir / "rasters"
    gates_dir = outdir / "gates"
    rasters_dir.mkdir(parents=True, exist_ok=True)
    gates_dir.mkdir(parents=True, exist_ok=True)

    candidates = make_candidates()
    winner, ranking = auto_select_candidate(candidates)
    roi_xywh = estimate_candidate_roi(winner)

    canonical_sequence: dict[str, dict[str, Any]] = {}
    attempt_history: list[dict[str, Any]] = []
    auto_rejections = 0
    prev_sha: str | None = None

    for stage in AUTONOMOUS_STAGE_SEQUENCE:
        if stage == "D0":
            b_info = canonical_sequence["B"]
            canonical_sequence["D0"] = {
                "stage": "D0",
                "image_path": b_info["image_path"],
                "sha256": b_info["sha256"],
                "parent_sha256": b_info["sha256"],
                "passed": True,
                "quality_score": b_info["quality_score"],
                "elevation_level": "k=0_TOPOLOGY_FREEZE",
            }
            prev_sha = b_info["sha256"]
            continue

        stage_files: list[Path] = []
        if stage_candidates_map and stage in stage_candidates_map:
            stage_files = [Path(p) for p in stage_candidates_map[stage]]
        else:
            if simulate_fault_injection and stage == "D2":
                bad_p = rasters_dir / f"{stage}_attempt01_fault_outer_shaft.jpg"
                render_synthetic_stage_raster(bad_p, stage, inject_fault="outer_end_shaft")
                stage_files.append(bad_p)
            elif simulate_fault_injection and stage == "E_END":
                bad_p = rasters_dir / f"{stage}_attempt01_fault_flipped_handle.jpg"
                render_synthetic_stage_raster(bad_p, stage, inject_fault="flip_handle_right")
                stage_files.append(bad_p)
            good_p = rasters_dir / f"{stage}_canonical.jpg"
            render_synthetic_stage_raster(good_p, stage)
            stage_files.append(good_p)

        stage_passed = False
        best_attempt: CandidateAttemptRecord | None = None
        elevation = "k=3_MV_CONTRACT"

        for idx, cand_path in enumerate(stage_files, start=1):
            sha = sha256_file(cand_path)
            passed, score, gates, reasons = audit_candidate_frame(stage, cand_path, prev_sha256=prev_sha)
            repair_note = None
            if not passed:
                auto_rejections += 1
                patch = compile_elevation_prompt_repair(winner, stage, prev_sha, reasons)
                elevation = patch["elevation_level"]
                repair_note = f"AUTO_REJECT_AND_ROLLBACK_TO_{(prev_sha or 'STAGE_A')[:10]} -> {elevation}"
                (gates_dir / f"REJECTED_{stage}_attempt{idx:02d}_repair_prompt.txt").write_text(
                    patch["repaired_prompt"], encoding="utf-8"
                )

            rec = CandidateAttemptRecord(
                stage=stage,
                attempt_index=idx,
                image_path=str(cand_path),
                sha256=sha,
                parent_sha256=prev_sha,
                elevation_level=elevation,
                passed=passed,
                quality_score=score,
                gates=[g.to_dict() for g in gates],
                rejection_reasons=reasons,
                repair_action_taken=repair_note,
            )
            attempt_history.append(asdict(rec))
            (gates_dir / f"gate_{stage}_attempt{idx:02d}.json").write_text(
                json.dumps(asdict(rec), indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
            if passed:
                best_attempt = rec
                stage_passed = True
                break
            if best_attempt is None or rec.quality_score > best_attempt.quality_score:
                best_attempt = rec

        assert best_attempt is not None
        locked_dest = rasters_dir / f"LOCKED_{stage}_{winner.candidate_id}.jpg"
        if Path(best_attempt.image_path).resolve() != locked_dest.resolve():
            shutil.copy2(best_attempt.image_path, locked_dest)

        canonical_sequence[stage] = {
            "stage": stage,
            "image_path": str(locked_dest),
            "sha256": best_attempt.sha256,
            "parent_sha256": prev_sha,
            "passed": stage_passed,
            "quality_score": best_attempt.quality_score,
            "elevation_level": best_attempt.elevation_level,
            "gates": best_attempt.gates,
        }
        if stage_passed:
            prev_sha = best_attempt.sha256

    stage_a_raster = Path(canonical_sequence["A"]["image_path"])
    build_packet(
        outdir=outdir / "compiled_packet",
        selected_id=winner.candidate_id,
        source_raster=stage_a_raster,
        roi=roi_xywh,
        auto_select=True,
    )

    video_manifest = build_video_transition_manifest(canonical_sequence, winner.candidate_id)
    passed_count = sum(1 for item in canonical_sequence.values() if item["passed"])
    report = AutonomousPipelineReport(
        workflow="autonomous-self-auditing-planted-double-ended-hammer-bubble-pipeline",
        selected_candidate_id=winner.candidate_id,
        auto_selection_score=ranking[0]["total_score"],
        total_stages=len(AUTONOMOUS_STAGE_SEQUENCE),
        passed_stages=passed_count,
        total_attempts=len(attempt_history),
        auto_rejections_and_rollbacks=auto_rejections,
        all_stages_passed=(passed_count == len(AUTONOMOUS_STAGE_SEQUENCE)),
        canonical_sequence=canonical_sequence,
        attempt_history=attempt_history,
        video_transition_manifest=video_manifest,
    )
    board_path = create_audit_contact_board(report, outdir / "AUTONOMOUS_AUDIT_SUMMARY_BOARD.jpg")
    report.summary_board_path = str(board_path)

    (outdir / "AUTONOMOUS_RUN_MANIFEST.json").write_text(
        json.dumps(report.to_dict(), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return report


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir", type=Path, default=Path("out/autonomous_run"))
    parser.add_argument("--simulate-fault-injection", action="store_true",
                        help="Inject faulty candidates on D2 and E_END to verify auto-rejection & rollback")
    parser.add_argument("--candidates-json", type=Path, default=None,
                        help="Optional JSON mapping stage names to lists of raster file paths")
    args = parser.parse_args(list(argv) if argv is not None else None)

    stage_map: dict[str, Sequence[Path]] | None = None
    if args.candidates_json and args.candidates_json.is_file():
        raw = json.loads(args.candidates_json.read_text(encoding="utf-8"))
        stage_map = {k: [Path(p) for p in v] for k, v in raw.items()}

    report = run_autonomous_pipeline(
        args.outdir,
        stage_candidates_map=stage_map,
        simulate_fault_injection=args.simulate_fault_injection,
    )
    print(json.dumps({
        "selected_candidate_id": report.selected_candidate_id,
        "auto_selection_score": report.auto_selection_score,
        "passed_stages": f"{report.passed_stages}/{report.total_stages}",
        "total_attempts": report.total_attempts,
        "auto_rejections_and_rollbacks": report.auto_rejections_and_rollbacks,
        "all_stages_passed": report.all_stages_passed,
        "manifest": str(args.outdir / "AUTONOMOUS_RUN_MANIFEST.json"),
        "summary_board": report.summary_board_path,
    }, indent=2, ensure_ascii=False))
    return 0 if report.all_stages_passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
