#!/usr/bin/env python3
"""Shannon Information Gain Diagnostic Engine for Planted Bubble Hammer (PR #6)."""
from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from typing import Any, Sequence


@dataclass(frozen=True)
class ShannonDiagnosticAxis:
    axis_id: str
    name_zh: str
    prior_fail_prob: float
    inspection_cost_units: float
    diagnostic_check: str
    repair_action: str


SHANNON_DIAGNOSTIC_AXES: tuple[ShannonDiagnosticAxis, ...] = (
    ShannonDiagnosticAxis(
        axis_id="BASE_SEAT_CONTACT_P_FAIL",
        name_zh="柱底貼合座與接觸點 P 脫離或無發光",
        prior_fail_prob=0.35,
        inspection_cost_units=1.0,
        diagnostic_check="檢查泡殼側弧形底座是否 100% 貼合泡殼曲率並鎖定於接觸點 P 發光",
        repair_action="Lock conformal circular base seat flush at contact point P with cyan-white collar glow.",
    ),
    ShannonDiagnosticAxis(
        axis_id="HANDLE_REGENERATION_OR_TILT",
        name_zh="側面 90° 切線橫柄被重生、分叉或外端蓋長出新桿",
        prior_fail_prob=0.45,
        inspection_cost_units=1.0,
        diagnostic_check="檢查握柄是否維持柱身側面中段單一 90° 直桿且外端蓋 C_outer 100% 空置",
        repair_action="Preserve existing single straight 90-degree side-middle rod handle; keep outer circular cap 100% bare.",
    ),
    ShannonDiagnosticAxis(
        axis_id="PERSON_GRIP_TOPOLOGY_FAIL",
        name_zh="人物未握住既有握柄或為配合手部位置重新生成新桿",
        prior_fail_prob=0.40,
        inspection_cost_units=1.1,
        diagnostic_check="檢查 D2/D3 手臂是否只移動去握住原圖已存在的那條橫柄",
        repair_action="Move ONLY the warrior's forearms/hands to wrap around the existing straight rod handle; forbid new shafts.",
    ),
    ShannonDiagnosticAxis(
        axis_id="CRACK_ORIGIN_CAUSALITY_FAIL",
        name_zh="E_MID / E_END 裂紋未從同一接觸點 P 向外擴散",
        prior_fail_prob=0.30,
        inspection_cost_units=1.2,
        diagnostic_check="檢查放射狀裂紋與碎片是否嚴格以接觸點 P 為唯一震央向外擴散",
        repair_action="Anchor all radial spiderweb cracks and outward shell shards strictly at contact point P.",
    ),
    ShannonDiagnosticAxis(
        axis_id="INHABITANT_SAFETY_SANCTUARY_BREACH",
        name_zh="泡殼內部聖城建築或居民受損",
        prior_fail_prob=0.25,
        inspection_cost_units=1.2,
        diagnostic_check="檢查內部暖金梯田聖城與居民是否保持完好無損（只破外殼）",
        repair_action="Freeze interior warm-golden miniature terraced sanctuary city and inhabitants 100% intact.",
    ),
    ShannonDiagnosticAxis(
        axis_id="UNAUTHORIZED_FREEZE_REGION_MODIFIED",
        name_zh="凍結遮罩區域（背景錨點、外端蓋、非編輯區）發生未授權像素漂移",
        prior_fail_prob=0.30,
        inspection_cost_units=0.9,
        diagnostic_check="檢查 freeze_mask 區域之合成後像素漂移是否為 0",
        repair_action="Composite with parent raster using freeze_mask so all non-editable pixels remain 100% locked.",
    ),
    ShannonDiagnosticAxis(
        axis_id="NOOP_SUBFRAME_REJECTED",
        name_zh="可編輯遮罩區域無實質變化（No-Op 子幀）",
        prior_fail_prob=0.20,
        inspection_cost_units=0.8,
        diagnostic_check="檢查 edit_mask 區域之平均亮度變化 (edit_region_mae_luma) 是否高於最小門檻",
        repair_action="Ensure the stage's authorized physical action produces a measurable change inside edit_mask.",
    ),
)


def calculate_entropy(p: float) -> float:
    if p <= 0.0 or p >= 1.0:
        return 0.0
    return -(p * math.log2(p) + (1.0 - p) * math.log2(1.0 - p))


def rank_diagnostics_by_information_gain(
    active_failure_axes: Sequence[str] = (),
) -> list[dict[str, Any]]:
    active_set = set(active_failure_axes)
    rows: list[dict[str, Any]] = []
    for ax in SHANNON_DIAGNOSTIC_AXES:
        is_active = ax.axis_id in active_set
        eff_p = 0.50 if is_active else ax.prior_fail_prob
        ig_bits = calculate_entropy(eff_p)
        boost = 2.0 if is_active else 1.0
        efficiency = (ig_bits * boost) / max(ax.inspection_cost_units, 1e-6)
        d = asdict(ax)
        d["is_targeted_failure"] = is_active
        d["expected_information_gain_bits"] = round(ig_bits, 4)
        d["efficiency_bits_per_cost"] = round(efficiency, 4)
        rows.append(d)
    rows.sort(
        key=lambda r: (r["is_targeted_failure"], r["efficiency_bits_per_cost"], r["expected_information_gain_bits"]),
        reverse=True,
    )
    return rows
