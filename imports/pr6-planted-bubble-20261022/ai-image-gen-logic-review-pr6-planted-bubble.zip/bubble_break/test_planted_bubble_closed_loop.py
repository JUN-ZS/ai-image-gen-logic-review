#!/usr/bin/env python3
"""Unit tests for `planted_bubble_closed_loop.py`, `planted_bubble_information_gain.py`, and `gemini_planted_bubble_provider.py`."""
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from PIL import Image, ImageDraw

from bubble_break.frame_pipeline import sha256_file
from bubble_break.gemini_planted_bubble_provider import (
    GeminiPlantedBubbleProvider,
)
from bubble_break.planted_bubble_closed_loop import (
    PLANTED_7STAGES,
    run_planted_bubble_closed_loop,
)
from bubble_break.planted_bubble_information_gain import (
    SHANNON_DIAGNOSTIC_AXES,
    calculate_entropy,
    rank_diagnostics_by_information_gain,
)


class PlantedBubbleClosedLoopTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.stage_imgs: dict[str, Path] = {}
        for idx, st in enumerate(PLANTED_7STAGES):
            p = self.root / f"stage_{st}.png"
            im = Image.new("RGB", (512, 512), (14, 18, 24))
            draw = ImageDraw.Draw(im)
            draw.rectangle([30 + idx * 18, 120, 160 + idx * 22, 420], fill=(60 + idx * 25, 110 + idx * 15, 170))
            im.save(p, format="PNG")
            self.stage_imgs[st] = p

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_shannon_entropy_and_diagnostic_ranking(self) -> None:
        self.assertAlmostEqual(calculate_entropy(0.5), 1.0, places=4)
        ranking = rank_diagnostics_by_information_gain(["HANDLE_REGENERATION_OR_TILT"])
        self.assertEqual(len(ranking), len(SHANNON_DIAGNOSTIC_AXES))
        self.assertEqual(ranking[0]["axis_id"], "HANDLE_REGENERATION_OR_TILT")
        self.assertTrue(ranking[0]["is_targeted_failure"])
        self.assertGreater(ranking[0]["expected_information_gain_bits"], 0.0)

    def test_gemini_vision_judge_schema_contract(self) -> None:
        prov = GeminiPlantedBubbleProvider()
        res = prov.audit_raster_with_vision_judge(
            "D2",
            self.stage_imgs["D2"],
            parent_sha="0" * 64,
            locked_master_sha="1" * 64,
        )
        self.assertTrue(res.passed)
        self.assertTrue(res.delivered_is_composited)
        self.assertEqual(res.judge_model_id, "gemini-3.8-flash")
        self.assertEqual(res.judge_status, "GEMINI_STRUCTURED_VISION_AUDIT_PASS")

    def test_planted_bubble_closed_loop_delivers_composited_image_and_rejects_noop(self) -> None:
        noop_cands = {
            "B": [(self.stage_imgs["B"], {"parent_sha": None})],
            "C": [(self.stage_imgs["B"], {"parent_sha": "AUTO_CHAIN"})],
        }
        rep_noop = run_planted_bubble_closed_loop(
            self.root / "out_noop",
            stage_candidates=noop_cands,
            min_edit_mae=0.8,
        )
        self.assertFalse(rep_noop.all_stages_passed)
        self.assertEqual(rep_noop.status, "BLOCKED_PLANTED_BUBBLE_STAGE_REJECTED")
        self.assertIn("NOOP_SUBFRAME_REJECTED", rep_noop.attempt_history[-1]["failure_axes"])

        stage_cands = {
            st: [(self.stage_imgs[st], {"parent_sha": "AUTO_CHAIN" if st != "B" else None})]
            for st in PLANTED_7STAGES
        }
        rep = run_planted_bubble_closed_loop(
            self.root / "out_planted",
            stage_candidates=stage_cands,
            min_edit_mae=0.8,
        )
        self.assertEqual(rep.status, "PASSED_PLANTED_BUBBLE_CLOSED_LOOP")
        self.assertEqual(rep.passed_stages, 7)
        self.assertEqual(rep.code_visual_acceptance_status, "NOT_VERIFIED_BY_CODE")
        for st in PLANTED_7STAGES:
            st_info = rep.stages[st]
            self.assertTrue(st_info["delivered_is_composited"])
            self.assertEqual(st_info["raster_sha256"], st_info["composited_sha256"])
            self.assertEqual(st_info["raster_sha256"], sha256_file(Path(st_info["raster_path"])))
            self.assertEqual(st_info["composited_freeze_region_mae_luma"], 0.0)
        self.assertTrue(Path(rep.filmstrip_path).is_file())
        self.assertTrue(Path(rep.evidence_board_path).is_file())


if __name__ == "__main__":
    unittest.main()
